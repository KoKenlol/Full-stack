<template>
    <div class="q-gutter-md" style="max-width:400px">
        <q-form @submit.prevent="onSubmit" class="q-gutter-md">
            <q-input v-model="id" label="ID" readonly />
            <q-input v-model="first_name" label="firstname" />
            <q-input v-model="last_name" label="lastname" />
            <q-input v-model="email" label="email" />
            <q-input v-model="address" label="address" />
            <q-input v-model="phone_number" label="phonenumber" />
            <q-btn type="submit" label="Update" color="primary" />
        </q-form>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()

const id = ref(route.params.id || '')
const first_name = ref('')
const last_name = ref('')
const email = ref('')
const address = ref('')
const phone_number = ref('')

const fetchData = async () => {
    if (!id.value) return

    try {
        const response = await fetch(`http://localhost:8800/api/v1/customers/${id.value}`)
        if (!response.ok) throw new Error('Failed to fetch customer data')

        const result = await response.json()
        first_name.value = result.first_name
        last_name.value = result.last_name
        email.value = result.email
        address.value = result.address
        phone_number.value = result.phone_number
    } catch (error) {
        console.error(error)
        alert(`Error: ${error.message}`)
    }
}

onMounted(fetchData)

const onSubmit = async () => {
    if (!id.value) {
        alert('Invalid customer ID')
        return
    }

    try {
        const response = await fetch(`http://localhost:8800/api/v1/customers/${id.value}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                first_name: first_name.value,
                last_name: last_name.value,
                email: email.value,
                address: address.value,
                phone_number: phone_number.value
            })
        })

        if (!response.ok) {
            const errorResponse = await response.json()
            throw new Error(errorResponse.message || 'Something went wrong!')
        }

        const result = await response.json()
        alert(result.message)
        console.log(result)

        if (result.status === 'ok') {
            router.push('/')
        } else {
            fetchData()
        }

    } catch (error) {
        console.error(error)
        alert(`Error: ${error.message}`)
    }
}
</script>
